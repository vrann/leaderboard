var modules = require('./index.js')
modules.scheduleBatchJobs();
//modules.checkIntegrity();
