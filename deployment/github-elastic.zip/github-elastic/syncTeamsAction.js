var modules = require('./index.js')
modules.synchronizeTeams();